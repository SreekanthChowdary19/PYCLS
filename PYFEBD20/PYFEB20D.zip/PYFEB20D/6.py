Python 3.7.0 (v3.7.0:1bf9cc5093, Jun 27 2018, 04:06:47) [MSC v.1914 32 bit (Intel)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> 

>>> 
>>> 
>>> 
>>> a = 10
>>> a
10
>>> # To check the type of any object ==> type(object)
>>> type(a)
<class 'int'>
>>> 
>>> b = 12.5
>>> 
>>> b
12.5
>>> type(b)
<class 'float'>
>>> c = "xya"
>>> c
'xya'
>>> type(c)
<class 'str'>
>>> a
10
>>> # To get the address of an object ==> id(object)
>>> id(a)
261765520
>>> 
>>> id(b)
35546528
>>> id(c)
36419008
>>> c = 10 # python is dynamic typed programming language
>>> 
>>> c
10
>>> 
>>> type(c)
<class 'int'>
>>> id(c)
261765520
>>> 
>>> a = 12
>>> 
>>> a
12
>>> type(a)
<class 'int'>
>>> 
>>> id(a)
261765552
>>> 
>>> 
