"""
What is function?

Purpose of the functions?

Function Definition

Function call

Function Return statement


Actual args vs Formal args

Default vs Non-default args

Positinal argumnets

variable number of args

Keyword args

Function overloading vs function overriding


Call by value vs Call by ref

Neasted functions

Recursive functions

Higher order functions

Generator

Decorator
"""
