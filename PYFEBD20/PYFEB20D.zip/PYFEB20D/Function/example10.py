#   with if - block can we write else? YE

"""
The else-block we can use not only conditional statements, we can also use
with itertaive statemnets and alos exceptional handiling
"""

"""
x = [2, 4, 6, 8]

for i in x:
     print(i)
else:
     print("Loop is success")
"""

"""
x = [2, 4, 6, 8]

for i in x:
     print(i)
else:
     print("Loop is success")
"""

x = [2, 4, 6, 7,  8]


for i in x:
     if i == 17:
          break
     print(i)
else:
     print("For is success")
