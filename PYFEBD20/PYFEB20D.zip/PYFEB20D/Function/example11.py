# Recursive functions-calling same function itself

# 5 ! = 5*4*3*2*1

# 5! = 4 * 4!
# 4! = 4 * 3!
# 3! = 3 * 2!
# 2! = 2 * 1!


def get_rec_fact(n):
     if n <=1:
          return 1
     else:
          return n*get_rec_fact(n-1)



r = get_rec_fact(5)
print(r)
