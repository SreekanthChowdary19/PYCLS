# Functional Programming

# Case1
"""
x = 10   # Gloabl variable 
def fun1():
     print(x)



fun1()


print(x)
"""


# Case2
"""
x = 10  # global variable

def fun1():
   x = 20  # local variable
   print(x)  # 20

print(x) #10
fun1()
print(x) # ? 10
"""
x = 10  # global variable

def fun1():
   global x
   x = 20  # local variable
   print(x)  # 20

print(x) #10
fun1()
print(x) # ? 20











