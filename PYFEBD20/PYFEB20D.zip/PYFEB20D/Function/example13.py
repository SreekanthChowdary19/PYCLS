
"""
def fun1(x):
     print(x)


fun1(10)  # int OBJECT
fun1(12.6) # flat OBJECT
fun1("BANGALORE") # string OBJECT
fun1([10, 20, 30]) # list OBJECT
fun1((10, 20, 30, 40)) # tuple OBJECT
fun1({"A": 65, "B": 66})# dict OBJECT
"""

# IN PYTHON ANYTHING IS AN OBJECT

# What about the function?
"""
YES, IN python function will act like a object

Like other objects, we can pass function as a argumnet to another function
and even we can return a function as a return value from the another function
"""


def square(n):
     return n*n

print(square)

s = square

print(s)


print(s(10))








