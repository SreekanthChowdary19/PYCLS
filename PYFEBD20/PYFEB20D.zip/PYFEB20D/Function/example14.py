"""
map(<function>, <sequence>)

filter()
"""

"""
def sqaure(n):
     return n*n

x = [2, 4, 6, 8]


y = list(map(sqaure, x))

print(y)

"""


#Filter
def is_even(n):
     if n % 2 ==0:
          return True
     else:
          return False

x = range(20)

y = list(filter(is_even, x))
print(y)










     
     

#filter(function, seq)

"""
y = []

for e in x:
     y.append(e*e)

print(y)
"""
