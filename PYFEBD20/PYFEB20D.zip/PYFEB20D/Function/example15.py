# What is the differance between map() filter()



def square(n):
     return n*n

"""
y = list(map(square, [2, 4, 6, 8]))
print(y)


y = list(filter(square, [2, 4, 6, 8]))
print(y)


"""

def is_even(n):
     if n % 2 == 0:
          return True
     else:
          return False


#y = list(filter(is_even, range(10)))
#print(y)


y = list(map(is_even, range(10)))
print(y)
