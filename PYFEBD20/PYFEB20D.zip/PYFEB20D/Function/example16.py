"""
def square(n):
     return n*n

"""

"""
def is_even(n):
     if n % 2 == 0:
          return True
     else:
          return False
"""

y = list(map(lambda e:e*e, [2, 4, 6, 8]))
print(y)


y = list(filter(lambda e: e%2==0, range(10)))
print(y)

"""
1. Function object
2. Higher order function
3. map() vs Filter
4. Ananomous function : lambda operator

"""
