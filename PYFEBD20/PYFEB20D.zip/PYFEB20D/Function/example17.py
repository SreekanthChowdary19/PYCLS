
# break and continue with loops

import sys

def  gfr(n):
     if n<= 1:
          return 1
     else:
          return n * gfr(n-1)



#print(gfr(5))

print(sys.getrecursionlimit())

sys.setrecursionlimit(5000)
print(gfr(1000))
