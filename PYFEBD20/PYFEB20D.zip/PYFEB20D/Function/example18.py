# Command line args 

import sys

args = sys.argv[1:]

print(args)

def add(x, y):
     return x+y

def sub(x, y):
     return abs(x-y)


if len(args) !=3 :
     sys.exit("Exited with invalid opration")
n1 = int(args[1])
n2 = int(args[2])

if args[0] == '-a':
     print(add(n1, n2))
elif args[0] == '-s':
     print(sub(n1, n2))
else:
     print("Invalid args : ")

"""
x = int(input("Enter a 1st value: "))

y = int(input("Enter a 1st value: "))

op = input("Enter a choise: (a-add, s-sub):")

if op == 'a':
     print(add(x, y))
elif op == 's':
     print(sub(x, y))
else:
     print("Invalid option")
"""
     
