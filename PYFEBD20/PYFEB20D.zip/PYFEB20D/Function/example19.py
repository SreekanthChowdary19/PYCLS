# Nestead functions


#  The function definition will execute when you call that function 

"""
def outerfun():
     print("Inside outer function")
     def innerfun():
          print("Inside inner function")



outerfun()
"""

"""
def outerfun():
     print("Inside outer function")
     def innerfun():
          print("Inside inner function")
     innerfun()

outerfun()
"""

# Higher orderfunction
"""
1. either function will take another function as an argumnets
or
2. The function will return another function as a returns
map() filter()
"""
"""
def outerfun():
     print("Inside outer function")
     def innerfun():
          print("Inside inner function")
     return innerfun

s = outerfun()

print(s())

"""

"""
def outerfun():
     x = 10
     y = 20
     def innerfun():
          z = 30
          print("Outer x: {} Outer y: {} Inner z: {}".format(x, y, z))
     innerfun()

outerfun()
"""

# clusures 
def outerfun():
     x = 10
     y = 20   # local variables to outer function # within the function
     def innerfun():
          z = 30
          print("Outer x: {} Outer y: {} Inner z: {}".format(x, y, z))
     return innerfun

s = outerfun()

s() # calling inner function


















