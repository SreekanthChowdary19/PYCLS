"""
What is function?   Its a pice of code and it will perfrom specific task

The function can does one job at a time

Functions are two types
     Built-in functions - len() dir() type() id() range()
               - List --> append() pop() index() count() etc.
               - Strings --> split() vs join(), lower(), upper(), capitalize()
               - Tuple -> count() index()
               - Dict --> keys(), values() items() etc
     User-defined functions
          as per the product demands - programmer defined functions 
"""

# Function definition
"""
Where exactly the logic of the function job implemented

SYNATX:

def <function_name>(args):
    # st1
    # st2
    # st3
    # return statement  # Optional

The function will gets execute when we call the function
"""
# How to call a function
"""
We can call a function using functio name by passing required argumnets
"""

# function definition
def display():
     print("Hello Welcome to python")


display() # function calling 

















