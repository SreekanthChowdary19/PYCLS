"""
The inner function will make a copy of outer function variable
which is being used before it retuns form

the outerfyunction 

"""


def outerfun():
     x = 10
     y = 20   # local variables to outer function # within the function
     w = 20
     n = 60
     def innerfun():
          z = 30
          print("Outer x: {} Outer y: {} Inner z: {}".format(x, y, z))
          print(n)
     return innerfun

s = outerfun()

print(s.__closure__)


s() # calling a inner function
