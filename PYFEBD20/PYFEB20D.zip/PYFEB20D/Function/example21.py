

"""
def funman(x):
     print(x(10))


def square(n):
     return n*n


funman(square)
"""


#   decorator -->  @classmethod @staticmethod


#  MYHOUSE --->  DECORATE -->  DIFFERENT WAYS

"""

Without using inheritance 
If you want enhance existing function or class feature we can use decorators
"""

def mydesign(funobj):
     def decorator():
          resp = funobj()
          resp = "*" * 10 + "\n" + resp + "\n" + "*" *10
          return resp
     
     return decorator


@mydesign
def  hello_world():
     message = "Welcome to Python Wrold"
     return message

#resp = hello_world()
#print(resp)



#resp = mydesign(hello_world)

#print(resp)


resp = hello_world()
print(resp)

















