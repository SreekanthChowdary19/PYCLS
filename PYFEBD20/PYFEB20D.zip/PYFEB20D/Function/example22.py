import psutil   # thirdpart module monitor the process realte utilities

#  name, pid, description, state , memort, cpu  createa a module as per your project
# spec

# get the running process my system

# 
# process life cycle

for proc in psutil.process_iter():
     name = proc.name()
     #print(proc.pid)
     if name.startswith('s'):
          print(name)




# Perfromace testing ==>  System memory ==> application ,   your application ==> different services

# each service how much memory is taking

# Tool implemnetation  to measurr ethe performance of our application 
# Giving explore
# get all top 5 process drwa a liner graph 
