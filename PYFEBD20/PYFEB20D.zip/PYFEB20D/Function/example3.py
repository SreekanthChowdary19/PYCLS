# WAP add two numbers


def add(x, y):
    c = x+y
    print(c)


add(10, 20)

