# WAP add two numbers and multiply result with 100

"""
The variables which we ahve defined inside a function definition are the local
variables

Local variables we are not allowd to access outside of the function definition
"""
def add(x, y):
    c = x+y
    print(c)


add(10, 20)
print(c*100) # Error c is not defined 
