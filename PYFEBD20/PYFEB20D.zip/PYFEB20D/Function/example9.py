#  WAP find even numbers from 1 to 100


"""

def get_evens(limit):
    x = range(limit)
    evens = []
    for i in x:
         if i % 2 ==0:
              evens.append(i)
    return evens


x = int(input("Enter upper limit: "))

result = get_evens(x)
print(result)
"""

"""
Generator its function, it will returns a generator object

We have to use yiled key word to create a generator object


"""


def get_evens(limit):
    x = range(limit)
    for i in x:
         if i % 2 ==0:
              yield i



r = get_evens(10)

for v in r:
     print(v)








