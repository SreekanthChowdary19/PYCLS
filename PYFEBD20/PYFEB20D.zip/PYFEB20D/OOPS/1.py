def add(x, y):
     c = x+y



add(10, 20)

print(c*100)
