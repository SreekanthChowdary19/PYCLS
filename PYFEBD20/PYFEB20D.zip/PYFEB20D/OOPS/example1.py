"""
Class : Representation of object attributes and Behaviours - Logical Entity


Object : Real Entity --> instance of a class


We can create N-number of objects to the class


OBJECT

Attributes - state of the object
Behaviours - Action doing by the object

Examples

Person - name, age, ht
          walk() speak()


Window -  lenght , width, color

          re-size move-left move-right ,  style-change

Attributes we can define with Datatypes
          ----- Data members of a class or object
Behaviours we will define with functions

          ----  Member functions or methods

"""

# How to define a class?
"""
using 'class' keyword we can define a class

SYNTAX:

class <ClassName>:
     Attributes
     Behaviours
"""


class Student:

     def display():
          print("Inside init method")


# Calling a function
display() # NameError: name 'display' is not defined

























