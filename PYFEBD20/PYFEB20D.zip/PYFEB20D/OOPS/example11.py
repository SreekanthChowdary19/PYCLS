#
"""
__str__:    Its a tostring method python, In general if you access
object directly we will get an address of the object
if you try to access the obejct directly it will print the return value of the
to string method
"""

class Shape:

     def __init__(self, xcor, ycor):
          self.x = xcor
          self.y = ycor

     def move(self):
          self.x = self.x+100
          self.y = self.y+100
     """
     def display(self):
          print("x: {} and y: {}".format(self.x, self.y))
     """
     # tostring method
     def __str__(self):
          return ("x: {} and y: {}".format(self.x, self.y))


s1 = Shape(10, 20)
print(s1) # getting address of an object
