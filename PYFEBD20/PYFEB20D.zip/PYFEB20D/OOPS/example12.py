# instance method vs class method vs staticmethod

"""
Have you used any decorators? YES -->  @classmethod @staticmethod
Have you implemented any decorators?  --> will be cover in functional programming
"""


class Student:

     count = 0 

     # initilizes OBJECT infromation
     def __init__(self, name, age, ht):
          self.Name = name
          self.age = age
          self.HT = ht
          Student.count = Student.count +1

     # display OBJECT infromation
     def display(self):
          print("Name:{} age:{} HT: {}".format(self.Name, self.age, self.HT))

    # Get the count of CLASS
     @classmethod
     def get_total(cls):
          print("Total number of students: {}".format(cls.count))

     @staticmethod
     def get_avg():
         print("Satic method")

s1 = Student("Hareesh", 24, 5.6)
s2 = Student("Mahesh", 25, 5.7)
s3 = Student("Suresh", 26, 5.8)

s1.get_avg()
             
Student.get_avg()

