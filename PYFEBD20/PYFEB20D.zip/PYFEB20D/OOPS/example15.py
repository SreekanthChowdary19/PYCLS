"""
Single Inheritance
A
|
|
B
"""

class A:

     def go(self):
          print("GO A Go!")

     def ready(self):
          print("Ready A ready")

     def stop(self):
          print("Stop A stop")
# We are inherited A class(Paraent or Base)
#inside a B-class (Child-Derived)

class B(A):

     def go(self):
          print("Go b go")

     def ready(self):
          print("G B ready")


b = B()

b.go()
b.ready()
b.stop()
