"""
Multilevel inheritance 
A
|
B
|
C
"""

class A:

     def go(self):
          print("GO A Go!")

     def ready(self):
          print("Ready A ready")

     def stop(self):
          print("Stop A stop")
# We are inherited A class(Paraent or Base)
#inside a B-class (Child-Derived)

class B(A):

     def go(self):
          print("Go b go")

     def ready(self):
          print("G B ready")

class C(B):

     def ready(self):
          print("Ready C Ready")


c = C()
c.go()
c.ready()
c.stop()
