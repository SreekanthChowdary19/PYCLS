"""
Multiple Inheritance
MRO: Method Resolution Order : 
"""

class A:

     def go(self):
          print("GO A Go!")

     def ready(self):
          print("Ready A ready")

     def stop(self):
          print("Stop A stop")


class B:

     def go(self):
          print("Go b go")

     def ready(self):
          print("G B ready")

class C(A,B):

     def stop(self):
          print("stop C stop")

c = C()
c.stop()
c.go()

