"""
class Service:

     def start_service():
        pass
     def stop_service(self):
          pass

     def get_service_name():
          pass

     def get_pid():
          pass


class WinService(Service):


     def start_service()
         print("Start service")


class LinService(Service):

     def start_service()
         print("Start service")

     pass
"""



"""
class Driver:
     pass


class ChromeDeriver(Driver):
     pass

class FireFoxDriver(Driver):
     pass
"""








