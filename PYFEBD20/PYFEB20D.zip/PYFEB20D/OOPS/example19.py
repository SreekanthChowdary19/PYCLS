"""
Same method in different froms
"""

class Shape:

     def __init__(self, xcor, ycor):
          self.x = xcor
          self.y = ycor

     def move(self):
          self.x = self.x+100
          self.y = self.y+100

     def __str__(self):
          return ("x: {} y: {}".format(self.x, self.y))


#s1 = Shape(10, 20)
#print(s1)

class Rect(Shape):

     def __init__(self, xcor, ycor, width, height):
          Shape.__init__(self, xcor, ycor)
          self.h = height
          self.w = width

     def move(self):
          self.x = self.x+200
          self.y = self.y+200
          self.w = self.w+200
          self.h = self.h+200

     def __str__(self):
          return ("x: {} y: {} h: {} w: {}".format(self.x, self.y, self.h, self.w))


r1 = Rect(10, 20, 30, 40)
print(r1)
r1.move()
print(r1)

