"""
If we want access the class members we have access through
object of that class
"""

# How to create a object

"""
We can create a object using class name
"""

class Student:

     def display():
          print("Inside display method")


# Object creation

x = Student() # s1 is a object or instance of a class Student

x.display() # TypeError: display() takes 0 positional arguments but 1 was given
