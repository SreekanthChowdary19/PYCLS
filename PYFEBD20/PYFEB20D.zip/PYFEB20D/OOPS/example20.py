def add(x, y):
     return x+y


print(add(10, 20)) # 30


def add(x, y, z):
     return x+y+z


print(add(10, 20, 30)) # 60


print(add(100, 200)) # 300

#TypeError: add() missing 1 required positional argument: 'z'
 
