class stack:

     def __init__(self, size):
          self.size = size
          #self.top = 0
          self.x = []

     def get_top(self):
          return len(self.x)

     def is_full(self):
         if len(self.x) == self.size:
               return True

     def is_empty(self):
         if len(self.x) == 0:
               return True

     def pop(self):
          if not self.is_empty():
              ele = self.x.pop()
              return ele
          else:
               raise Exception("Stack is empty")

     def append(self, ele):
          if not self.is_full():
              self.x.append(ele)
          else:
               raise Exception("Stack overflow error")

     def __str__(self):
          return "{}".format(self.x)


exp = "{()}]"
opens = ['{', '(']
closes = ['}', ')', ']']

s1 = stack(10)
for d in exp:
     if d in opens:
          s1.append(d)
     elif d in closes:
          s1.pop()

size = s1.get_top()
if size != 0:
     print("Not a balanced expression")
else:
     print("Expression is balanced")




