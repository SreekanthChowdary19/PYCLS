

class Shape:

     def __init__(self, xcor, ycor):
          self.x = xcor
          self.y = ycor
     """
     def __str__(self):
          return "{}, {}".format(self.__class__.__name__, self.__dict__)
     """

s1 = Shape(10, 20)

print(s1.__dict__)


s1.__dict__['x'] = 100
print(s1.__dict__)

print(s1.__dict__['x'])


del s1.__dict__['x']

#print(s1.__dict__['x'])

print(s1.__dict__)
# getattr setattr
