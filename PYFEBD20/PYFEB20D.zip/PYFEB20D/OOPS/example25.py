class Facebook:


     def __init__(self):
          pass

     def _read_input(self):
          pass


     def _validate_user_input(self):
          pass

     def _check_db(self):
          pass


     def login(email, password):
          f._read_input()
          f._validate_user_input()
          f._check_db()
          pass



#--------------------------------

f = Facebook()

f.login()
# Hiding 
