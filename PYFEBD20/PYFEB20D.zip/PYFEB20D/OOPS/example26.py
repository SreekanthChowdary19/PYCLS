# recursive functions

# factorial   5! ==> 5*4*3*2*1




def get_fact(n):
     fact = 1
     for i in range(1, n+1):
          fact = fact * i
     return fact
     
res = get_fact(5)
print(res)




