"""
A self param is used to differentiate on which object we are invoking a function
The current class object ===> this  pointer == self
"""

class Student:

     def display(self):
          print(self)  # Address of an object i.e which is invoking display method
          print("Inside display function")


s1 = Student()  # object creation

s2 = Student()  # object creation 

print(s1)  # Address of an object s1

s1.display() # display(s1)
print("="*30)
print(s2)   # Address of an object s2
s2.display() # display(s2)

