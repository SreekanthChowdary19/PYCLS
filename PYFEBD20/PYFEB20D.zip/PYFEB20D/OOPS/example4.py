"""
__init__ is a special method in python
We can call it as a constructor

As programmer we no need call this method
the interpreter will invoke this method at the time object creation 
"""

class Student:

     def __init__(self):
         print("Inside init mehod")

     def display(self):
          print("Inside display method")


s1 = Student() # Object creation , it will invoke __init__() method

s1.display()
