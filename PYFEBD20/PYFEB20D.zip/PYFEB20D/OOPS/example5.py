"""
__init__ is a special method in python
We can call it as a constructor

As programmer we no need call this method
the interpreter will invoke this method at the time object creation

If we create N-objects the __init__() will invoke N-times
"""

class Student:

     def __init__(self):
         print("Inside init mehod")

     def display(self):
          print("Inside display method")


s1 = Student()  #object creation statement , init method will invoke
s2 = Student()  # object creation statement , init method will invoke
s3 = Student()  # object creation .. init method will invoke

s1.display()   # calls a dispaly function with object s1
s3.display()   # calls a display function with object s3
