class Student:
     pass

s1 = Student()

s2 = Student()


# We are initlizing common attributes of an object i.e name, age, ht

s1.name = "Hareesh"
s1.age = 24
s1.ht = 5.6


s2.name = "Mahesh"
s2.age = 25
s2.ht = 5.7

print("Name: {} Age: {} Height: {}".format(s1.name, s1.age, s1.ht))


print("Name: {} Age: {} Height: {}".format(s2.name, s2.age, s2.ht))
