"""
Instance variables : will be created a separate copy for each object 
"""

class Student:

     def __init__(self, name, age, ht):
          self.Name = name
          self.age = age
          self.HT = ht

     def display(self):
          print("Name:{} age:{} HT: {}".format(self.Name, self.age, self.HT))


s1 = Student("Hareesh", 24, 5.6)
s2 = Student("Mahesh", 25, 5.7)

s1.display()
s2.display()
