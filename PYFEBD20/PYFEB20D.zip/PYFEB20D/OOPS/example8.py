"""
Instance variables : will be created a separate copy for each object
Class variable" will create one copy per class

all the objects can share this value

if any object changes the class level variable it reflect to all other objects
"""
#count = 0 # Global variable

class Student:

     count = 0 # class variable
     
     def __init__(self, name, age, ht):
          self.Name = name
          self.age = age
          self.HT = ht
          Student.count = Student.count +1

     def display(self):
          print("Name:{} age:{} HT: {}".format(self.Name, self.age, self.HT))

     def get_total(self):
          print("Total number of students: {}".format(Student.count))


s1 = Student("Hareesh", 24, 5.6)
s2 = Student("Mahesh", 25, 5.7)
s3 = Student("Suresh", 26, 5.8)
             
#s1.display()
#s2.display()



s1.games = "YES"


print(dir(s1))
print(dir(s2))


