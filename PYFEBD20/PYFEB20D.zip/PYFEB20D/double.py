x=[2,4,6,8]
#indexes=range(0,len(x))
for i in x:
     x[i]=x[i]*x[i]
print(x)     
