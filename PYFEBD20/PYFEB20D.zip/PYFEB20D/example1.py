Python 3.7.0 (v3.7.0:1bf9cc5093, Jun 27 2018, 04:06:47) [MSC v.1914 32 bit (Intel)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> 

>>> x = [10, 20, 30, 40]
>>> x
[10, 20, 30, 40]
>>> type(x)
<class 'list'>
>>> 
>>> x
[10, 20, 30, 40]
>>> x
[10, 20, 30, 40]
>>> 
>>> # To compute size of a given list we can use ==> len(object)
>>> 
>>> len(x)
4
>>> x[0]
10
>>> x[1]
20
>>> x[2]
30
>>> x[3]
40
>>> x[len(x)-1]
40
>>> 
