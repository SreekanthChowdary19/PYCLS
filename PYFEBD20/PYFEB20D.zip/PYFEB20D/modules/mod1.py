# module --> standard libraries or built-n libraries 20 to 30 modules


# random -module  (gropu of functions)


import random # We have included random module in our projet file


# To access functions inside a module we have to call a function with module name



num = random.randint(100, 1000)
print(num)


"""
report_456.html
report_678.html
"""
