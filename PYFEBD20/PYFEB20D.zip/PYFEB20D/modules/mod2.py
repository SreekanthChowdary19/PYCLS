# WAP generate 10 random numbers of 3 digits 

"""
import random
rand_nums = []
for i in range(10):
    num = random.randint(100, 999)
    rand_nums.append(num)

print(rand_nums)


"""

count control loop or infinite loop
initilzation


while <cond>:
    # incremetation

"""
"""
# print 5 numbers

i = 1


while i <= 5:
     print(i)
     i = i+1

print("Ouside while loop")
"""




rand_nums = []
i = 0
while i < 10:
    num = random.randint(100, 999)
    rand_nums.append(num)
    i = i+1

print(rand_nums)








