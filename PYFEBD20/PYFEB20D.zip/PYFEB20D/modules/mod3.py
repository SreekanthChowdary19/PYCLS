# infinite loop
import time

while True:
     print(" connecting a server....")
     time.sleep(2)
     x = input("Enter Q to quite: ")
     print(x)
     if x == 'Q':
          break
print("Outside of the loop")


"""import sys
while True:
     print(" connecting a server....")
     time.sleep(2)
     x = input("Enter Q to quite: ")
     print(x)
     if x == 'Q':
          sys.exit()
print("Outside of the loop")"""
