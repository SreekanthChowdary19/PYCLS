# os - filemanagemnet ,processmanagement, memeory

# WAP list all the folders and files from the given path
import os


path = "C:\\Program Files\\Arduino"


resp = os.listdir(path)


print(resp)
"""
if 'arduino.exe' in resp:
     print("Success Installation")

"""

for f in resp:
     if f.endswith('.exe'):
          print(f)

