# traversing file system

import os

path = "C:\\Program Files\\Arduino"



#resp = os.walk(path)

#print(resp)
resp = os.walk(path)
"""
i = 100
for x in resp:
     print("="*40)
     print(x)
     print(type(x))
     print(len(x))
     i = i -1
     if i == 0:
          break
"""
     
for root, folders, files in os.walk(path):
     for f in files:
          if f.endswith(".sys"):
               print(f)
