import os
import time


path = "C:\\Program Files\\Arduino"
for item in os.walk(path):
     time.sleep(2)
     print(item)
