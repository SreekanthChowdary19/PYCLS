# command line operations

"""
Operating SYStem (Windows) commnds
     set dns - command
     drive map - commad
     ip address - command
     proces list tasklist

Linux commands:
     ls
     pwd
     grep
     top
     tail

Windows Applications 

Install the product :
          - Download exe file and double click
          - Command line installation or scilent installation
     
"""
# We can run any program as a command like standard commands

import os

#cmd = 'ipconfig /flushdns'
cmd2 = "tasklist"
ret = os.system(cmd2)
if ret == 0:
     print("Command executed successfully. {}".format(cmd2))
else:
     print("Fail to execute command. {}".format(cmd2))
