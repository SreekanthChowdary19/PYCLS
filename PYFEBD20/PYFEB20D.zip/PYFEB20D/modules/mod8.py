# Running a command and read the console output from the command
# os


import subprocess



resp = subprocess.check_output('tasklist')

print(type(resp))

resp = resp.decode('utf-8')

print(type(resp))

print(resp)
#resp = resp.split("\n")





