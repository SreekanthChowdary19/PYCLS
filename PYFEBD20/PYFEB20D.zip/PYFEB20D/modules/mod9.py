"""
Module --> Library or collection related function

     Built-in types ==>  os, sys, time, subprocess, scoket
          Once install a python the built modules will be available in your syatem




          Automation + Framework developemnt 
          
     Third-party modules
               We have to install explicitly by using pip or esay_install, direct source code
               -- twiitet , facebook, youtube, git, JIRA, jenkins
               -- matplotlib, pandas, numpy, scipy , seaborn -->
               -- Oracle, MySQL, Mongodb , sqlite3
               -- wxpython , tkinter, pyqt  QtCreator
               -- skiilearn, tensorflow
               -- PIL, OpenCV2
               -- flask, Django, Turnod
               -- SMTP, HTTP, SNMP, SSH, FTP
               -- IOT
               -- pyspark
               -- AWS
               Platofrom 
               
     User-defined modules
"""
