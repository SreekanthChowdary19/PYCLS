random -  used to genarate a random number

time - used to give sleep time


sys -- to exit the application
