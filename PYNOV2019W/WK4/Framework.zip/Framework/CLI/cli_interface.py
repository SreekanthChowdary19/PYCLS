import os
import subprocess


def run_command(cmd):
    res = os.system(cmd)
    if res == 0:
        return True
    else:
        return False

def get_commnad_response(cmd):
    try:
        resp = subprocess.check_output(cmd)
        resp = resp.decode('utf-8')
        return resp
    except:
        print("Invalid command")