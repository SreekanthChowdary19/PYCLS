"""
SYNTAX ERRORS
LOGICAL ERRORS or RUNTIME ERRORS
"""

def add(x, y):
    return x+y

def sub(x, y):
    return x-y

def mul(x, y):
    return x*y

def div(x, y):
    return x//y

if __name__ == "__main__":
    """
    print(add(10, 20))
    print(sub(20, 10))
    print(mul(30, 2))
    print(div(10, 2))
    """
    print(div(10, 0))