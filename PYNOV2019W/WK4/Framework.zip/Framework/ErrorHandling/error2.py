"""
Runtime errors we can call it as exceptions

Handling runtime errors are nothing but exception handling

We can handle exception with help of below

try  : Which ever the exceptional causing statement we need to put inside try-block
except : Once exception arises what acttion user has to take we need to put inside except-block

*raise

*finally

*else

"""