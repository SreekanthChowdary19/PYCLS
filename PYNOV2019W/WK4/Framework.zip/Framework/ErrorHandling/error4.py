
# Same piece of code may cause multiple exceptions




def add(x, y):
    return x+y

def sub(x, y):
    return x-y

def mul(x, y):
    return x*y

def div(x, y):
    try:
        return x//str(y)
    except ZeroDivisionError:
        print("Please pass second value as non-zero")
    except Exception as e:
        print("Unknown error: " + str(e))


if __name__ == "__main__":
    """
    print(add(10, 20))
    print(sub(20, 10))
    print(mul(30, 2))
    print(div(10, 2))
    """
    print(div(10, 2))