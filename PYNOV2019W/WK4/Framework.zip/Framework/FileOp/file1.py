""""
# OPEN
<fileobject>  open(<filepath>, <mode>)

mode ==> r ==> reading
         w ===> writing
         a ===> appending

#READ

<string> read()
<List> readlines()


# CLOSE

close()
"""

path = "C:\\Users\\user\\Desktop\\WK4\\AutoFramewrok\\dependeccies\\zen_of_python.txt"
f = open(path, 'r')
data = f.read()
f.close()

print(data)