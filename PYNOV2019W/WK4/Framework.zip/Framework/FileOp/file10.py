

def append_file(path, data):
    f =open(path, "a")
    f.write(data)
    f.close()