import os

path = os.getcwd()

path = path.split("\\")[:-1]
path = "\\".join(path)
print(path)

path = path + "\\" + "depend\\zen_of_python.txt"

if os.path.exists(path):
    print("File path Exist")
else:
    print("File not found")

f = open(path, 'r')
data = f.read()
f.close()

print(data)
