import os


def read_file(filepath):
    f = open(filepath, 'r')
    data = f.read()
    f.close()
    return data

def is_path_exist(path):
    if os.path.exists(path):
        return True
    else:
        return False



if __name__ == "__main__":
    path = os.getcwd()
    path = path.split("\\")[:-1]
    path = "\\".join(path)
    path = os.path.join(path, "depend", "zen_of_python.txt")
    if is_path_exist(path):
         data = read_file(path)
         print(data)


