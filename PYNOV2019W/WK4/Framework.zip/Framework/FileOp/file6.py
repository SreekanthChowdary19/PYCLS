# Write data inside a file

"""
<fileobejct> open(filepath, 'mode')

# WRITE

write(<data_in_string>)

writelines(<data_in_list>)

# CLOSE

close
Note: If we are opening a file in write mode ,

when the file is not exist it will create a new file
"""

f = open('output.txt', 'w')
f.write("PYTHON HELLO WORLD")
f.close()


