import os

path = os.getcwd()
path = path.split("\\")[:-1]
path = "\\".join(path)
path = os.path.join(path, "results", "output.txt")

f = open(path, 'w')
f.write("PYTHON HELLO WORLD")
f.close()
