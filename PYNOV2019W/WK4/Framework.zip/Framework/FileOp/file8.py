
"""
When we are opening an existing file in write mode
it will overide the data

"""
import os

path = os.getcwd()
path = path.split("\\")[:-1]
path = "\\".join(path)
path = os.path.join(path, "results", "output.txt")

f = open(path, 'w')
f.write("PYTHON IS VERY EASY PROGRAMMING LANGUAGE")
f.close()