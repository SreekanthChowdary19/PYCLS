from time import gmtime, strftime
import os

def get_sys_time():
    tm = strftime("%d_%m_%Y-%H_%M_%S", gmtime())
    return tm

def write_file(filepath, data):
    f = open(filepath, 'w')
    f.write(data)
    f.close()

if __name__ == "__main__":
    path = os.getcwd()
    path = path.split("\\")[:-1]
    path = "\\".join(path)
    sys_time = get_sys_time()
    file_name = "output_" + sys_time + ".txt"
    path = os.path.join(path, "results", file_name)
    write_file(path, "ABCD")
