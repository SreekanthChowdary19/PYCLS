

def read_file(filepath):
    try:
        f = open(filepath, 'r')
        data = f.read()
        f.close()
        return data
    except IOError:
        print("File not found : {}".format(filepath))
    except Exception as e:
        print("Unknow error : {}".format(str(e)))

def read_file_lines(filepath):
    try:
        f = open(filepath, 'r')
        data = f.readlines()
        f.close()
        return data
    except IOError:
        print("File not found : {}".format(filepath))
    except Exception as e:
        print("Unknow error : {}".format(str(e)))

def write_file(filepath, data, mode='w'):
    f = open(filepath, mode)
    f.write(data)
    f.close()
