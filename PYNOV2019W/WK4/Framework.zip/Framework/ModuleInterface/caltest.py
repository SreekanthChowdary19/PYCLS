"""
from calc import add


print(add(10, 20))

print(sub(20, 10))
"""


#from calc import *

import calc as c

print(c.add(10, 20))


from calc import add as a
