Python 3.7.0 (v3.7.0:1bf9cc5093, Jun 27 2018, 04:06:47) [MSC v.1914 32 bit (Intel)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> 
== RESTART: C:\Users\user\Desktop\WK4\AutoFramewrok\ModuleInterface\calc.py ==
>>> import os
>>> os.getcwd()
'C:\\Users\\user\\Desktop\\WK4\\AutoFramewrok\\ModuleInterface'
>>> # Case1
>>> """
Import module directly with name using "import" statemnet
and call function with module name dot nottaion
"""
'\nImport module directly with name using "import" statemnet\nand call function with module name dot nottaion\n'
>>> import calc
>>> calc.add(10, 20)
30
>>> calc.sub(20, 10)
10
>>> 
=============================== RESTART: Shell ===============================
>>> # Case2: Import required functions
>>> from calc import add, sub
Traceback (most recent call last):
  File "<pyshell#9>", line 1, in <module>
    from calc import add, sub
ModuleNotFoundError: No module named 'calc'
>>> import os
>>> os.getcwd()
'C:\\Users\\user\\AppData\\Local\\Programs\\Python\\Python37-32'
>>> 
