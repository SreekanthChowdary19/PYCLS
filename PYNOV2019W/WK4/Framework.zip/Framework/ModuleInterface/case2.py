Python 3.7.0 (v3.7.0:1bf9cc5093, Jun 27 2018, 04:06:47) [MSC v.1914 32 bit (Intel)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> 
== RESTART: C:\Users\user\Desktop\WK4\AutoFramewrok\ModuleInterface\calc.py ==
>>> # Case2
>>> 
>>> from calc import add, sub
>>> 
>>> 
>>> sub(10, 20)
-10
>>> add(20, 10)
30
>>> mul(2, 4)
8
>>> div(10, 2)
5
>>> 
