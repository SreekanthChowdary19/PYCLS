"""
What is a Module?

Its collection of multiple related functions

Types:
Built-in modules os, subprocess

by default avaulable in our system once after python  installation
it will stored in path
C:\Users\user\AppData\Local\Programs\Python\Python37-32\Lib

Third-party modules : cx_oracle, JIRA....
It will not avaialble in our system. we have to install explicilty
by using pip command
C:\Users\user\AppData\Local\Programs\Python\Python37-32\Lib\site-packages

User-defined modules?
In python each .py file will act as a module. and the file name is act as a module name

"""