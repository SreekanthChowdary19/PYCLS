from FileOp.file_operations import *
from CLI.cli_interface import *
import os

path = "C:\\Users\\user\\Desktop\\WK4\\AutoFramewrok\\depend\\cmd_input.txt"

cmnds = read_file_lines(path)
output_path = "C:\\Users\\user\\Desktop\\WK4\\AutoFramewrok\\results"
for cmd in cmnds:
    cmd = cmd.rstrip()
    fila_path = "output_" + cmd + ".txt"
    output_path =  os.path.join(output_path, fila_path)
    resp = get_commnad_response(cmd)
    write_file(output_path, resp)
    print(resp)

    print("="*100)
