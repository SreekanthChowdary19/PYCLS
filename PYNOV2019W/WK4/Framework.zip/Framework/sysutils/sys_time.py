


from time import gmtime, strftime


time = strftime("%Y-%m-%d %H:%M:%S", gmtime())
print(time)